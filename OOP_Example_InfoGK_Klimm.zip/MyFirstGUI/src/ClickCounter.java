
public interface ClickCounter {
	public int getClicks();
	public void setClicks(int y);
}
