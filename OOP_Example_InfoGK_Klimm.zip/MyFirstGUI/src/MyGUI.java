import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.xml.bind.TypeConstraintException;

public class MyGUI extends JFrame implements ActionListener{

	private JFrame myFrame;
	private JPanel myPanel;
	private JLabel myLabel;
	private JButton myButton, myButton2;
	private String x = "test"; 
	private int i = 0;

	private int clicks;
	
	// constructor
	public MyGUI() {
		this.myFrame = new JFrame(); // Window
		this.myPanel = new JPanel(); // Panel
		this.myLabel = new JLabel("0"); // Text Label
		this.myButton = new JButton("button1"); // Button
		this.myButton2 = new JButton("button2"); // Button 69
		
		// add listener
		this.myButton.addActionListener(this);
		this.myButton2.addActionListener(this);

		// configure panel
		this.myPanel.setBorder(BorderFactory.createEmptyBorder(42, 69, 42, 69));
		this.myPanel.setLayout(new GridLayout(0, 1));

		// add components to panel
		this.myPanel.add(this.myButton);
		this.myPanel.add(this.myButton2);
		this.myPanel.add(this.myLabel);

		// add panel to frame
		this.myFrame.add(this.myPanel);

		// exit on close
		this.myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// set title
		this.myFrame.setTitle("You got me some BEEEEAAANNSS? Thats pretty neat");

		// pack to fit only everything
		this.myFrame.pack();

		// made visible
		this.myFrame.setVisible(true);

	}

	// main method
	public static void main(String[] args) {
		// new object of class
		MyGUI Fenster = new MyGUI();
		

	}
	
	// getter and setter
	public JFrame getMyFrame() {
		return myFrame;
	}

	public void setMyFrame(JFrame myFrame) {
		this.myFrame = myFrame;
	}

	public JPanel getMyPanel() {
		return myPanel;
	}

	public void setMyPanel(JPanel myPanel) {
		this.myPanel = myPanel;
	}

	public JLabel getMyLabel() {
		return myLabel;
	}

	public void setMyLabel(JLabel myLabel) {
		this.myLabel = myLabel;
	}

	public JButton getMyButton() {
		return myButton;
	}

	public void setMyButton(JButton myButton) {
		this.myButton = myButton;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		this.i++;
		this.myLabel.setText(String.valueOf(i));
		
	}

}
