import javax.swing.*;


public class MyGUI {
	
	private JFrame myFrame;
	private JPanel myPanel;
	private JLabel myLabel;
	private JButton myButton;
	
	public MyGUI() {

	}
	
	public static void main(String[] args) {
		MyGUI GUI = new MyGUI(); //new object of class
		
		// initialize things
		GUI.myFrame = new JFrame("Frame 1");
		GUI.myPanel = new JPanel();
		GUI.myLabel = new JLabel("Label 1");
		GUI.myButton = new JButton("Drücken se ma hier...");
		
		// settings: exit when frame closed
		GUI.myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// add components to Panel
		GUI.myPanel.add(GUI.myButton);
		
		// add Panel to Frame
		GUI.myFrame.add(GUI.myPanel);

		// pack to fit only everything
		GUI.myFrame.pack();

		// make Frame visible
		GUI.myFrame.setVisible(true);
		
	}
	
	

	public JFrame getMyFrame() {
		return myFrame;
	}

	public void setMyFrame(JFrame myFrame) {
		this.myFrame = myFrame;
	}

	public JPanel getMyPanel() {
		return myPanel;
	}

	public void setMyPanel(JPanel myPanel) {
		this.myPanel = myPanel;
	}

	public JLabel getMyLabel() {
		return myLabel;
	}

	public void setMyLabel(JLabel myLabel) {
		this.myLabel = myLabel;
	}

	public JButton getMyButton() {
		return myButton;
	}

	public void setMyButton(JButton myButton) {
		this.myButton = myButton;
	}

}
