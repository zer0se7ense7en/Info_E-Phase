import javax.swing.JFrame;

public class maintest {

	public static void main(String[] args) {
		MyGUI GUI = new MyGUI(); //new object of class
		
		GUI.myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //exit when frame closed
		
		GUI.myFrame.getContentPane().add(GUI.myLabel, GUI.myButton);
		
		GUI.myFrame.pack();
		
		GUI.myFrame.setVisible(true);
		
	}
}
